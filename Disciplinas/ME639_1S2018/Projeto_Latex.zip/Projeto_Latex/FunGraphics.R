# Prepare -----------------------------------------------------------------  
rm(list=ls());gc()  
pkg <- c("ggplot2")  
inst <- pkg %in% installed.packages()  
if(length(pkg[!inst]) > 0) install.packages(pkg[!inst])  
lapply(pkg,library,character.only=TRUE)  
rm(inst,pkg)  
# Create dataset ----------------------------------------------------------  
d1 <- data.frame(member=c(rep("Homer",3),  
                          rep("Marge",3),  
                          rep("Bart",3),  
                          rep("Lisa",2),  
                          rep("Maggie",2)),  
                 shade=c("HomerPants","HomerShirt","Skin",  
                         "MargeDress","Skin","MargeHair",  
                         "BartShorts","BartShirt","Skin",  
                         "LisaDress","Skin",  
                         "MaggieOnesie","Skin"),  
                 height=c(20,20,25,  
                          40,20,40,  
                          15,15,18,  
                          28,15,  
                          18,11))  
d1$member <- ordered(d1$member,levels=c("Homer","Marge","Bart","Lisa","Maggie"))  
d1$shade <- ordered(d1$shade,levels=c("HomerPants","HomerShirt","Skin",  
                                      "MargeDress","MargeHair",  
                                      "BartShorts","BartShirt",  
                                      "LisaDress",  
                                      "MaggieOnesie"))  
# Chart the data ----------------------------------------------------------  
g1 <- ggplot(d1,aes(x=member,y=height,fill=shade)) +   
  geom_bar(stat="identity") +   
  scale_fill_manual(values=c("#4F76DF","#FFFFFF","#FFD90F",  
                             "#83C33F","#2359F1",  
                             "#6686C7","#E65120",  
                             "#DA6901",  
                             "#72C7E7")) +   
  theme(legend.position="none",  
        axis.title.x=element_blank(),  
        axis.title.y=element_blank(),  
        axis.text.x=element_blank(),  
        axis.text.y=element_blank()) +   
  ggtitle("Moe's Bar Chart")  
g1  
# Save image --------------------------------------------------------------  
png("Simpsons.png")  
g1  
dev.off() 



